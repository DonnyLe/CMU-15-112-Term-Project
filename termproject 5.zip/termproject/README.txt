Goal of the game: Climb up by grappling (click on the drone) on the drones. Get near misses to increase
your score multiplier. Avoid the bombs. The drones are the white circles while the bombs are the 
red circles. The character moves faster and the bomb placement gets harder as you get more points. 

When you start the game, input your username (case-sensitive)


R = Restart
G = Invincibility 
1,2,3,4 = Chooses the drone corresponding to the number from left to right 
H = Shows Hitbox
5 = Cuts the grapple (used for last resort measure to survive, 
                        control may change in the future )




