import math
#parent class
class gameObjects():
    def __init__(self, cx, cy, width, height):
        self.cx = cx
        self.cy = cy
        self.width = width/2
        self.height = height/2
       
    
    def move(self, dx, dy):
        self.cx += dx
        self.cy += dy
        #updates hitboxes
        hitboxCharacter = (self.cx, self.cy, self.width)
        self.hitboxes = [(hitboxCharacter)]
        
    
    def objectsIntersects(self, other):
        for characterCircle in other.hitboxes:
            for circles in self.hitboxes:
                cx0, cy0, r0 = circles
                cx1, cy1, r1 = characterCircle
                if (circlesIntersect(cx0, cy0, r0, cx1, cy1, r1)==True
                    ):
                    return True 
                
    #draws hitboxes
    def drawHitboxes(self, canvas):
        for hitbox in self.hitboxes:
            cx, cy, r = hitbox
            canvas.create_oval(cx-r, cy-r, cx+r, cy+r, outline="green", width = "3")

class Drone(gameObjects):
    def __init__(self, cx, cy, width, height):
        super().__init__(cx, cy, width, height)
        hitboxCharacter = (self.cx, self.cy, self.width)
        #list of circles to fill up model
        self.hitboxes = [(hitboxCharacter)]
        self.alreadyInteracted = False
        self.dyFallingDrone = 0


    def drawDrone(self, canvas, app):
        #**temp
        if(self.alreadyInteracted):
            self.fallingAnimation(app)
        canvas.create_oval(self.cx - self.width, self.cy - self.height,
                                self.cx + self.width, self.cy + self.height
                                )
    def fallingAnimation(self, app):
        self.dyFallingDrone += app.gravity
        super().move(0, self.dyFallingDrone)
        
    #checks if mouse clicks register on drone
    def isClicked(self, app):
        if (abs(app.mouseX - self.cx) <= self.width and
           abs(app.mouseY - self.cy) <= self.height
           and not self.alreadyInteracted
           ):
           return(True) 
        else:
            return (False)

class AngelDrone(Drone):
     def objectsIntersects(self, other, app):
        if super().objectsIntersects(self, other) and not self.alreadyInteracted:
            app.lives += 1

# class MissileDrone(Drone):
#     def missileLaunch(self, app):
#         for bomblist in app.allBombList:
#             for bomb in bomblist:
#                 pass
                


class ComboDrone(Drone):
    def objectsIntersects(self, other, app):
        if super().objectsIntersects(self, other) and not self.alreadyInteracted:
            app.combo += 1

#sub class of gameObjects
class Character(gameObjects):
    def __init__(self, cx, cy, width, height):
        super().__init__(cx, cy, width, height)
        hitboxCharacter = (self.cx, self.cy, self.width)
        #list of circles to fill up model
        self.hitboxes = [(hitboxCharacter)]
        

    def move(self, dx, dy, app):
        #vertical-screen scrolling
        if(self.cy) <= app.scrollMargin and dy<0:
            app.scrollY = dy - 1 
            dy = 0
            super().move(dx, dy)
        else:
            #stops scrolling
            app.scrollY = 0
            super().move(dx, dy)

        

    def drawCharacter(self, canvas):
        #**temp
        canvas.create_rectangle(self.cx - self.width, self.cy - self.height,
                                self.cx + self.width, self.cy + self.height
                                )
    #draws circle where combos are registered
    def drawComboCircle(self, canvas, app):
        canvas.create_oval(self.cx - app.comboRadius-self.width, self.cy - app.comboRadius-self.width,
                                self.cx + app.comboRadius+self.width, self.cy + app.comboRadius+self.width
                                ,outline = "blue", width = 3
                                )

#sub class of gameObjects
class Bomb(gameObjects):
    def __init__(self, cx, cy, r ):
        super().__init__(cx, cy, r*2, r*2)
        #temporary hitboxes
        hitboxBomb1 = (self.cx, self.cy, self.width)
        self.hitboxes = [(hitboxBomb1)]
        #one bomb can only give one combo 
        self.comboTaken = False
        #player needs to be in the combo radius for 150 ms
        self.nearMissTime = 0
        self.theta = 0
        

    def drawBomb(self, canvas):
        canvas.create_oval(self.cx - self.width, self.cy  - self.height,
                      self.cx + self.width, self.cy + self.height, fill = "red")
    
    #checks near misses
    def nearMiss(self,other, app):
        if not self.comboTaken:
            cx0, cy0,r0 = self.cx, self.cy, self.width
            cx1, cy1, r1= other.cx, other.cy, other.width
            distance = distanceFormula(cx0, cy0,r0, cx1, cy1, r1)
            if distance  -r0 - r1 <= app.comboRadius:
                return True 

    def drawExplosion(self, canvas, app):
        pass

class circlingBomb(Bomb):
    def __init__(self, cxsmall, cysmall, r, initialTheta, direction, cxlarge,cylarge):
        super().__init__(cxsmall, cysmall, r)
        self.tempcx = self.cx
        self.tempcy = self.cy
        self.theta = initialTheta
        self.direction = direction
        self.cxlarge = cxlarge
        self.cylarge = cylarge

    def circle(self, radius, dtheta):
        self.theta +=  dtheta * self.direction
        newposX = radius * math.cos(math.radians(self.theta)) + self.cxlarge
        newposY = radius *  math.sin(math.radians(self.theta)) + self.cylarge
        self.cx = newposX
        self.cy = newposY
    
    def move(self, dx, dy):
        super().move(dx, dy)
        self.cxlarge += dx
        self.cylarge += dy
        
        
        
class sideToSideBomb(Bomb):
    def __init__(self, cx, cy, r, leftbound, rightbound):
        super().__init__(cx, cy, r)
        self.leftbound = leftbound
        self.rightbound = rightbound
       


        
    

def circlesIntersect(cx0, cy0, r0, cx1, cy1, r1):
    distance = distanceFormula(cx0, cy0, r0, cx1, cy1, r1)
    if distance <= (r0 + r1):
        return True 

def distanceFormula(cx0, cy0, r0, cx1, cy1, r1):
    return ((cx0 - cx1)**2 + (cy0 - cy1)**2)**0.5

    