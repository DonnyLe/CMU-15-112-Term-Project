from objects import *
from main import * 
import random
#starting layer
def startingLayer(app):
    app.droneWidth = app.width/7
    app.character = Character(app.width/2, app.height-30, 30, 100)
    app.layerGuideLine1 = app.height/5
    app.startingLayer = [Drone(app.width/2, app.layerGuideLine1,  app.droneWidth,  app.droneWidth)]
    app.allBombList = []
    app.allDroneList = [app.startingLayer]
    app.layerGuideLine3 = None
    app.layerGuideLine2 = None
    app.easyprobability = 0.6
    app.mediumprobability = 0.3
    app.hardprobability = 0.1


def createLayer(app, layer):
    difficulty = 0
    if app.score >0:
        probabilitychange = (7 * math.log2(app.score)) /100
        
        app.hardprobability = 0.1 + probabilitychange * 2/3
        app.mediumprobability = 0.3 + probabilitychange * 1/3
        app.easyprobability = 0.6 - probabilitychange
    
    randFloat = random.random()

    if randFloat < app.hardprobability:
        difficulty = 3
    elif randFloat >= app.hardprobability and randFloat <app.hardprobability + app.easyprobability:
        difficulty = 2
    else:
        difficulty = 1
    print(difficulty)
    dronelist, bomblist = generateLayer(app, difficulty, layer, random.randint(1,4))

    app.allDroneList.append(dronelist)
    app.allBombList.append(bomblist)

def generateLayer(app, difficulty, layer, n):
    totalList = []
   
    mustHaveDroneCounter = 1
    dronelist = []
    bomblist = []
    

    if difficulty == 1:
        option1Probability = 3/4
        option2Probability = 1/8
        option3Probability = 1/16
        option4Probability = 1/16

    elif difficulty == 2:
        option1Probability = 1/4
        option2Probability = 1/4
        option3Probability = 1/4
        option4Probability = 1/4

    else:
        option1Probability = 1/8
        option2Probability = 1/8
        option3Probability = 3/8
        option4Probability = 3/8

    cx = random.uniform(app.width/(n*2+2), app.width/(n*2+1))
    i = 0
    while i< n:

        shift = random.randint(-10, 10)
        randFloat = random.random()
        if randFloat < option1Probability:
            totalList.append(Drone(cx, layer + shift, app.droneWidth, app.droneWidth))
            mustHaveDroneCounter -= 1
            cx += random.uniform(app.width/(n+1), app.width/n)
            i+= 1
        elif randFloat >= option1Probability and randFloat <option1Probability + option2Probability:
            totalList.append(Bomb(cx, layer + shift, app.droneWidth/2))
            cx += random.uniform(app.width/(n+1), app.width/n)
            i+= 1
        elif(randFloat >= option1Probability + option2Probability and randFloat <option1Probability + 
            option2Probability + option2Probability):

            circlingbomb = circlingBomb(cx, layer + shift, 
                            app.droneWidth/2, random.randrange(360), 
                            random.choice([-1, 1]), cx, layer + shift)
            circlingbomb.circle(100, 1)

            droneInCircle = Drone(cx,layer + shift, app.droneWidth, app.droneWidth)
            pair = [circlingbomb, droneInCircle]
            totalList.append(pair)
            
        
            if i>0 and isinstance(totalList[i], list) and isinstance(totalList[i-1], list) and isinstance(totalList[i][0], circlingBomb) and isinstance(totalList[i-1][0], circlingBomb): 
                print("entered")
                totalList.pop(i)
                
            else:
                i+= 1
                cx += random.uniform(app.width/(n+1), app.width/n) if n != 1 else random.uniform(app.width/(3), app.width/2)
        else:
            if n-i> 2:
                drone1 = Drone(cx,layer + shift, app.droneWidth, app.droneWidth)
                cx += random.uniform(app.width/(n+1), app.width/n) if n != 1 else random.uniform(app.width/(3), app.width/2)
                drone2 = Drone(cx,layer + shift, app.droneWidth, app.droneWidth)
                app.leftbound = drone1.cx
                app.rightbound = drone2.cx
                sidebomb = sideToSideBomb(cx, layer + shift, app.droneWidth/2,  app.leftbound,  app.rightbound)
                
                pair = [drone1, drone2, sidebomb]
                totalList.append(pair)
                i+=1
                n-=1 
                cx += random.uniform(app.width/(n+1), app.width/n) if n != 1 else random.uniform(app.width/(3), app.width/2)

    if i==n and mustHaveDroneCounter > 0:
        totalList[n-1] = Drone(cx-app.width/4,layer + random.randint(-10, 10), app.droneWidth, app.droneWidth) 
    
    
    flattenedList = flatten(totalList)
    for gameobject in flattenedList:
        if type(gameobject) == Drone:
            dronelist.append(gameobject)
        else:
            bomblist.append(gameobject)

    return dronelist, bomblist

#taken from recursion review session, 15112
def flatten(L):
    if L == []:
        return []

    if type(L[0]) != list:
        return [L[0]] + flatten(L[1:])
    
    return flatten(L[0]) + flatten(L[1:])



     
    
     








#python pickle, json file, csv file