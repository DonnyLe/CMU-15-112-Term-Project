#################################################
# Your name: Donny Le
# Your andrew id: dmle
#################################################

import math, copy, random
from cmu_112_graphics import *
from objects import *
from layers import *
#################################################
# Helper functions
#################################################

def almostEqual(d1, d2, epsilon=10**-7):
    # note: use math.isclose() outside 15-112 with Python version 3.5 or later
    return (abs(d2 - d1) < epsilon)

import decimal
def roundHalfUp(d):
    # Round to nearest with ties going away from zero.
    rounding = decimal.ROUND_HALF_UP
    # See other rounding options here:
    # https://docs.python.org/3/library/decimal.html#rounding-modes
    return int(decimal.Decimal(d).to_integral_value(rounding=rounding))

#################################ad################
# Functions for you to write
#################################################
def appStarted(app):   
    

    
    
    app.timerDelay = 16

    app.showHitBox = False
    app.comboRadius =40
    
    gameStarted(app)


def gameStarted(app):
    startingLayer(app)
    app.droneIntersected = False
    app.score = 0
    #score multiplier 
    app.combo = 1
    app.thirdLayerPlaced = False
    app.secondLayerPlaced = False
    app.mouseX = None
    app.mouseY = None

    app.gameOver = False
    app.gravity = 0.7
    app.velocity = 0
    app.grappleCoords1 = ()
    app.grappleCoords2 = ()
    app.grappleBoolean = False
    app.grappleTheta = None
    app.firstMove = True
    app.dx = 0
    app.dy = 0
    #used for physics 
    app.tempdx = 0
    app.tempdy = 0
    #used for sidescrolling
    app.scrollX = 0
    app.scrollY = 0
    app.scrollMargin = app.height * 2/3
    #used in falling animation
    app.dyFallingDrone = 0

    #used to correct directions with negative and positive slopes
    app.negativeDx = 1
    app.negativeDy = 1

    #
    app.currentDrone = None
    app.slope = None
    
def calculateVelocityComponents(app):
    dx =  math.cos(app.theta)*app.velocity * app.negativeDx
    dy = math.sin(app.theta)*app.velocity * app.negativeDy
    return dx, dy


    

def calculateSlope(app, x0, y0, x1, y1):
    #**used to correct directions with negative and positive slopes
    #positive, positive
    if(y1-y0>=0 and x1-x0>=0):
        app.negativeDx = -1
        app.negativeDy = -1
    #negative, negative
    elif(y1-y0 < 1 and x1-x0<1):
        app.negativeDx = 1
        app.negativeDy = 1
    #positive, negative
    elif(y1-y0 >= 0 and x1-x0<1):
        app.negativeDx = 1
        app.negativeDy = 1
    elif(y1-y0 < 1 and x1-x0>0):
        app.negativeDx = -1
        app.negativeDy = -1
    if(x1-x0!=0):
        return (y1-y0)/(x1-x0)
    return None
    
def mousePressed(app, event):
    app.mouseX = event.x
    app.mouseY = event.y
    for i in range(len(app.allDroneList)):
        for drone in app.allDroneList[i]:
            if drone.isClicked(app):
                selectDrone(app, drone)            
                getGrappleValues(app)
            
def selectDrone(app, drone):
    #gets the initial location of the clicked drone
    app.currentDrone = drone
    #used to prevent character from falling b/c gravity when game starts
    app.firstMove = False
    #starts all operations involving the grapple
    app.grappleBoolean = True
    #resets the initial velocity after grappling to 10 
    app.velocity = 10


def keyPressed(app, event):
    key = event.key
    if key == 'r':
        gameStarted(app)
    if key == 'h':
        app.showHitBox = not app.showHitBox
   
    appDistanceFromL1 = app.character.cy - app.layerGuideLine1
    if app.secondLayerPlaced:
        appDistanceFromL2 = app.character.cy - app.layerGuideLine2
    if app.thirdLayerPlaced:
        appDistanceFromL3 = app.character.cy - app.layerGuideLine3
    
    for i in range(len(app.allDroneList)):
        if (key.isdigit() and 
            int(key) <= len(app.allDroneList[i])) :
            drone = app.allDroneList[i][int(key)-1]
            if not drone.alreadyInteracted:
                selectDrone(app, drone)
                getGrappleValues(app)
                break
            

def getGrappleValues(app):
    #sets the grappleCoords to the drone's pos and character's pos 
    app.grappleCoords1 = (app.currentDrone.cx, app.currentDrone.cy)
    app.grappleCoords2 = (app.character.cx, app.character.cy)
    cx0, cy0 = app.grappleCoords1    
    cx1, cy1 = app.grappleCoords2
    #calculate slope and theta (in rads)
    app.slope = calculateSlope(app, cx0, cy0, cx1, cy1)
    if app.slope == None:
        app.theta = math.pi/2
    else:
        app.theta =(math.atan(app.slope))

def timerFired(app):

    if app.gameOver:
        return 
    #y axis scrolling, moves all objects but player down 
    if app.scrollY !=0:
        for i in range(len(app.allBombList)):
            for bomb in app.allBombList[i]:
                bomb.move(0, -app.scrollY)
    

        for j in range(len(app.allDroneList)):
            for drone in app.allDroneList[j]:
                drone.move(0, -app.scrollY)
        moveLayers(app)

    #checks if player hits the bomb
    for k in range(len(app.allBombList)):
        for bomb in app.allBombList[k]:
            if bomb.objectsIntersects(app.character) == True:
                app.velocity = 0
                app.gameOver = True
            else:
                #near miss checks
                if bomb.nearMiss(app.character, app):
                    #player needs to be near the bomb continuously for 150 ms
                    bomb.nearMissTime += app.timerDelay
                    if bomb.nearMissTime >= 100:
                        #combo doubles points
                        app.combo += 1
                        #prevents singular bomb from giving multiple combos
                        bomb.comboTaken = True
                #resets near-miss time
                else:
                    bomb.nearMissTime = 0
    #checks if player hits drone
    for e in range(len(app.allDroneList)):
        for drone in app.allDroneList[e]:
            if drone.objectsIntersects(app.character) == True and not drone.alreadyInteracted:
                #stops grappling
                if drone == app.currentDrone:
                    app.grappleBoolean = False
                #stops the same drone from giving multiple points
                drone.alreadyInteracted = True
                app.score += 1 * app.combo
            
            #starts the drone falling animation
            elif drone.alreadyInteracted == True:
                app.dyFallingDrone += app.gravity
                drone.move(0, app.dyFallingDrone)

                #removes drones that are out of bounds of playable area
                if (drone.cy > app.height
                    ):
                    app.dyFallingDrone = 0

 
    
        

    #moving the player
    if(not app.firstMove):
        if app.grappleBoolean:
            #updates grappleCoords 
            getGrappleValues(app)
            app.dx, app.dy = calculateVelocityComponents(app)
            #temps used for game physics
            app.tempdx = app.dx
            app.tempdy = app.dy
            #moves the character directly rto the given drone
            app.character.move(app.dx,app.dy, app)

        else:
            #slows down the y velocity drastically after it touches drone 
            #does not follow kinematics but works better for game
            dySlowDown = 1 * app.velocity/10

            if app.dy<= 0:
                app.dy += dySlowDown
            else:
                app.dy += app.gravity
            
            dxSlowDown = 0.3 * app.velocity/10
            if app.tempdx > 0 and app.dx - dxSlowDown > app.tempdx//2:
                app.dx -= dxSlowDown
            if app.tempdx < 0 and app.dx + dxSlowDown < app.tempdx//2:
                app.dx += dxSlowDown
            
            
                
                

            app.character.move(app.dx,app.dy, app)
    
    #checks if player is off the screevn (with leeway)
    if (app.character.cx-150 > app.width or app.character.cx+150 < 0 
        or app.character.cy - 150 > app.height):
        app.gameOver = True
    



        
"""
def rotationX(x, y, theta ):
    return x * math.cos(theta) + y * math.sin(theta)

def rotationY(x, y, theta):
    return -x * math.sin(theta) + y * math.cos(theta)
 """

def moveLayers(app):

    app.layerGuideLine1-= app.scrollY 
    if(app.secondLayerPlaced==False):
        if app.layerGuideLine1 > app.height/2.75:
            app.layerGuideLine2 = 0            
            app.secondLayerPlaced = True
            addLayer(app, app.layerGuideLine2)

    elif(app.thirdLayerPlaced==False):
        if app.layerGuideLine2 > app.height/2.75:
            app.layerGuideLine3 = 0
            app.thirdLayerPlaced = True
            addLayer(app, app.layerGuideLine3)

    else:
        if app.layerGuideLine1 > app.height:
            app.allDroneList.pop(0)
            app.layerGuideLine1 = app.layerGuideLine2
            app.layerGuideLine2 = app.layerGuideLine3
            app.layerGuideLine3 -= app.height/2.75
            addLayer(app, app.layerGuideLine3)
    
    if app.secondLayerPlaced:
        app.layerGuideLine2 -= app.scrollY 
    if app.thirdLayerPlaced:
        app.layerGuideLine3 -= app.scrollY 
#draws score
def drawScore(app,  canvas):
    canvas.create_text(app.width/2, 50, text=f'{app.score}', font="Arial 30 bold" )

#draws current combo
def drawCombo(app, canvas):
        canvas.create_text(app.width/2, app.height/2, text=f'{app.combo}x', font="Arial 50 bold")

def drawGameOver(app ,canvas):
    canvas.create_text(app.width/2, 150, text="You Lost",  font="Arial 50 bold" )

def drawGrappleHook(app, canvas):
    if app.gameOver:
        return 
    cx0, cy0 = app.grappleCoords1
    cx1, cy1 = app.grappleCoords2

    theta = app.theta
    #rotates grapple hook to face drone
    xprime0, yprime0 = 5 * math.cos(theta+math.pi/4) + cx0, 5 * math.sin(theta+math.pi/4) + cy0
    xprime1, yprime1 = 5 * math.cos(theta-math.pi/4) + cx0, 5 * math.sin(theta-math.pi/4) + cy0
    xprime2, yprime2 = 5 * math.cos(theta+math.pi/4) + cx1, 5 * math.sin(theta+math.pi/4) + cy1
    xprime3, yprime3 = 5 * math.cos(theta-math.pi/4) + cx1, 5 * math.sin(theta-math.pi/4) + cy1
    
    canvas.create_polygon( xprime1, yprime1, xprime0, yprime0,xprime2, yprime2, xprime3, yprime3)

def drawLayerGuideLine(app, canvas):
    canvas.create_line(0, app.layerGuideLine1, app.width, app.layerGuideLine1, width = 3)
    if app.thirdLayerPlaced:
        canvas.create_line(0, app.layerGuideLine3, app.width, app.layerGuideLine3, width = 3, fill = "blue")

    if app.secondLayerPlaced:
        canvas.create_line(0, app.layerGuideLine2, app.width, app.layerGuideLine2, width = 3, fill = "orange")


def redrawAll(app, canvas):
    drawCombo(app, canvas)
    drawScore(app, canvas)
    app.character.drawCharacter(canvas)
    if(app.grappleBoolean):
        drawGrappleHook(app, canvas)
    for i in range(len(app.allBombList)):
        for bomb in app.allBombList[i]:
            bomb.drawBomb(canvas)
    for j in range(len(app.allDroneList)):
        for drone in app.allDroneList[j]:
            drone.drawDrone(canvas)
            if app.showHitBox:
                drone.drawHitboxes(canvas) 
    if app.showHitBox:
        app.character.drawComboCircle(canvas, app)
        app.character.drawHitboxes(canvas) 
        drawLayerGuideLine(app, canvas)

    if app.gameOver:
        drawGameOver(app, canvas)

#################################################
# main
#################################################

def main():
    runApp(width=500, height=800)

if __name__ == '__main__':
    main()
