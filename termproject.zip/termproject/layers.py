from objects import *
from main import * 
import random
#starting layer
def startingLayer(app):
    app.character = Character(app.width/2, app.height-30, 30, 100)
    app.layerGuideLine1 = app.height/5
    app.startingLayer = [Drone(app.width/2, app.layerGuideLine1, app.width/7, app.width/7)]
    app.allBombList = []
    app.allDroneList = [app.startingLayer]
    app.layerGuideLine3 = None
    app.layerGuideLine2 = None

def createLayer(app):
    pass


# !temp
def layer1(app, layer):
    dronelist = [Drone(app.width * 1/5, layer- random.randrange(-10,10), app.width/10, app.width/10),
              Drone(app.width * 3/5, layer- random.randrange(-10,10), app.width/10, app.width/10),
              Drone(app.width * 4/5, layer- random.randrange(-10,10), app.width/10, app.width/10)]
    bomblist = [Bomb(app.width* 2/5, layer- random.randrange(-10,10), app.width/10)]
    difficulty = 1
    return dronelist, bomblist, difficulty

#!temp
def addLayer(app, layer):
     dronelist, bomblist, difficultylayer1 =  layer1(app, layer)
     app.allDroneList.append(dronelist)
     app.allBombList.append(bomblist)
     








#python pickle, json file, csv file